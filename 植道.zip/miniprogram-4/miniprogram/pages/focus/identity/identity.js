// pages/focus/identity/identity.js
const db = wx.cloud.database()
const _ = db.command
Page({

  /**
   * 页面的初始数据
   */
  data: {
    item: {
      topPPT: [
        { imagePath: "/images/juzi.jpg", },
        { imagePath: "/images/green.png", },
        { imagePath: "/images/juzi.jpg", },
        { imagePath: "/images/green.png", },
        { imagePath: "/images/juzi.jpg", },
        { imagePath: "/images/green.png", },
        { imagePath: "/images/juzi.jpg", },
        { imagePath: "/images/green.png", },
      ],
    },
    avatar: "/images/fanqie.jpg",
    comment: 0,
    content1: "巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉",
    content2: "拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉",
    date: "2019-02-20",
    like: 0,
    title: "这才是真正的柑橘痂疮病",
    view: 0,
    writer: "邓玲",
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log('页面参数', options)
    var tmpTitle = options.title;
    db.collection('identity').where({
      title: tmpTitle
    }).get({
      success: function (res) {
        console.log('数据库数据', res)
        me.setData({
          avatar: res.data[0].avatar,
          comment: res.data[0].comment,
          content1: res.data[0].content1,
          content2: res.data[0].content2,
          date: res.data[0].date,
          like: res.data[0].like,
          title: res.data[0].title,
          view: res.data[0].view,
          writer: res.data[0].writer,
        })
      }
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})