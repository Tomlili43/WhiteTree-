
const db = wx.cloud.database();
const _ = db.command;
const userInfo = db.collection('userInfo')
const paper = db.collection('paper');
const identity = db.collection('identity');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    value: '',
   index:true,
    // 推荐list 数据
    recommend: [
      {
        avatar: "/images/fanqie.jpg",
        comment: 0,
        content1: "巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉",
        content2: "拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉",
        date: "2019-02-20",
        like: 0,
        path: "/pages/focus/recommend/recommend2/recommend2",
        title: "这才是真正的柑橘痂疮病",
        view: 0,
        writer: "邓玲",
      },
    ],
    identity: [
      {
        avatar: "/images/fanqie.jpg",
        comment: 0,
        content1: "巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉",
        content2: "拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉",
        date: "2019-02-20",
        like: 0,
        path: "/pages/focus/recommend/recommend2/recommend2",
        title: "这才是真正的柑橘痂疮病",
        view: 0,
        writer: "邓玲22",
      },
    ]
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 数据增加
    // db.collection('paper').add({
    //   // data 字段表示需新增的 JSON 数据
    //   data: {
    //     // _id: 'todo-identifiant-aleatoire', // 可选自定义 _id，在此处场景下用数据库自动分配的就可以了
    //     avatar: "/images/fanqie.jpg",
    //     comment: 0,
    //     content1: "巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉",
    //     content2: "拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉",
    //     date: "2019-02-20",
    //     like: 0,
    //     path: "/pages/focus/recommend/recommend2/recommend2",
    //     title: "这才是真正的柑橘痂疮病",
    //     view: 0,
    //     writer: "邓玲",
    //   },
    //   success: function (res) {
    //     // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
    //     console.log(res)
    //   },
    //   fail: console.error,
    //   complete: console.log
    // })
    // db.collection('identity').add({
    //   // data 字段表示需新增的 JSON 数据
    //   data: {
    //     // _id: 'todo-identifiant-aleatoire', // 可选自定义 _id，在此处场景下用数据库自动分配的就可以了
    //     avatar: "/images/fanqie.jpg",
    //     comment: 0,
    //     content1: "巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉",
    //     content2: "拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉",
    //     date: "2019-02-20",
    //     like: 0,
    //     path: "/pages/focus/recommend/recommend2/recommend2",
    //     title: "这才是真正的柑橘痂疮病",
    //     view: 0,
    //     writer: "邓玲",
    //   },
    //   success: function (res) {
    //     // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
    //     console.log(res)
    //   },
    //   fail: console.error,
    //   complete: console.log
    // })
    // 推荐数据获取
    var me = this;
    db.collection('paper').get({
      success: function (res) {
        console.log(res.data)
        for (let i = 0; i <= 1; i++) {
          var avatar = "recommend[" + i + "].avatar"
          var comment = "recommend[" + i + "].comment"
          var content1 = "recommend[" + i + "].content1"
          var content2 = "recommend[" + i + "].content2"
          var date = "recommend[" + i + "].date"
          var like = "recommend[" + i + "].like"
          var path = "recommend[" + i + "].path"
          var title = "recommend[" + i + "].title"
          var view = "recommend[" + i + "].view"
          var writer = "recommend[" + i + "].writer"

          me.setData({
            [avatar]: res.data[i].avatar,
            [comment]: res.data[i].comment,
            [content1]: res.data[i].content1,
            [content2]: res.data[i].content2,
            [date]: res.data[i].date,
            [like]: res.data[i].like,
            [path]: res.data[i].path,
            [title]: res.data[i].title,
            [view]: res.data[i].view,
            [writer]: res.data[i].writer,
          })
        }
      },
      fail: console.error
    })
    // 鉴定数据库引入
    var me = this;
    db.collection('identity').get({
      success: function (res) {
        console.log(res.data)
        for (let i = 0; i <= 1; i++) {
          var avatar = "identity[" + i + "].avatar"
          var comment = "identity[" + i + "].comment"
          var content1 = "identity[" + i + "].content1"
          var content2 = "identity[" + i + "].content2"
          var date = "identity[" + i + "].date"
          var like = "identity[" + i + "].like"
          var path = "identity[" + i + "].path"
          var title = "identity[" + i + "].title"
          var view = "identity[" + i + "].view"
          var writer = "identity[" + i + "].writer"

          me.setData({
            [avatar]: res.data[i].avatar,
            [comment]: res.data[i].comment,
            [content1]: res.data[i].content1,
            [content2]: res.data[i].content2,
            [date]: res.data[i].date,
            [like]: res.data[i].like,
            [path]: res.data[i].path,
            [title]: res.data[i].title,
            [view]: res.data[i].view,
            [writer]: res.data[i].writer,
          })
        }
      },
      fail: console.error
    })

  },
  tabonClick:function(event){
    console.log('切换值',event.detail)
    this.setData({
     index: !this.data.index,
    })
  },
  onChange(e) {
    this.setData({
      value: e.detail
    });
  },
// this.data.value代表输入框的数据
  onSearch() {
    let plant = this.data.value
    console.log('onSearch搜索' + plant);
    if(this.data.index){
      this.recoSelect(plant);
    }
    else{
      this.idenSelect(plant);
    }

  },
  recoSelect: function (n) {
    const db = wx.cloud.database()
    var me = this
    db.collection('paper').where(_.or([{
      name: db.RegExp({
        regexp: '.*' + n,
        options: 'i',
      })
    },
    {
      address: db.RegExp({
        regexp: '.*' + n,
        options: 'i',
      })
    }
    ])).get({
      success: function (res) {
        console.log(res.data)
        me.setData({
          recommend: [],
        }, res2 => {
          for (let i = 0; i <= res.data.length-1; i++) {
            var avatar = "recommend[" + i + "].avatar"
            var comment = "recommend[" + i + "].comment"
            var content1 = "recommend[" + i + "].content1"
            var content2 = "recommend[" + i + "].content2"
            var date = "recommend[" + i + "].date"
            var like = "recommend[" + i + "].like"
            var path = "recommend[" + i + "].path"
            var title = "recommend[" + i + "].title"
            var view = "recommend[" + i + "].view"
            var writer = "recommend[" + i + "].writer"
            me.setData({
              [avatar]: res.data[i].avatar,
              [comment]: res.data[i].comment,
              [content1]: res.data[i].content1,
              [content2]: res.data[i].content2,
              [date]: res.data[i].date,
              [like]: res.data[i].like,
              [path]: res.data[i].path,
              [title]: res.data[i].title,
              [view]: res.data[i].view,
              [writer]: res.data[i].writer,
            })
          }
        })

      },
      fail: console.error
    })

  },
  // identity集合搜集数据
  idenSelect: function (n) {
    const db = wx.cloud.database()
    var me = this
    db.collection('identity').where(_.or([{
      name: db.RegExp({
        regexp: '.*' + n,
        options: 'i',
      })
    },
    {
      address: db.RegExp({
        regexp: '.*' + n,
        options: 'i',
      })
    }
    ])).get({
      success: function (res) {
        console.log(res.data)
        me.setData({
          identity:[],
        },res2=>{
          for (let i = 0; i <= res.data.length - 1; i++) {
            var avatar = "identity[" + i + "].avatar"
            var comment = "identity[" + i + "].comment"
            var content1 = "identity[" + i + "].content1"
            var content2 = "identity[" + i + "].content2"
            var date = "identity[" + i + "].date"
            var like = "identity[" + i + "].like"
            var path = "identity[" + i + "].path"
            var title = "identity[" + i + "].title"
            var view = "identity[" + i + "].view"
            var writer = "identity[" + i + "].writer"

            me.setData({
              [avatar]: res.data[i].avatar,
              [comment]: res.data[i].comment,
              [content1]: res.data[i].content1,
              [content2]: res.data[i].content2,
              [date]: res.data[i].date,
              [like]: res.data[i].like,
              [path]: res.data[i].path,
              [title]: res.data[i].title,
              [view]: res.data[i].view,
              [writer]: res.data[i].writer,
            })
          }
        })

      },
      fail: console.error
    })

  },

  onClick() {
    let plant = this.data.value
    console.log('onClick搜索' + plant);
    if (this.data.index) {
      this.recoSelect(plant);
    }
    else {
      this.idenSelect(plant);
    }
  },
  // getUserInfo: function (result) {
  //   console.log(result.detail.userInfo);
  //   userInfo.add({
  //     data: result.detail.userInfo
  //   }).then(res => {
  //     console.log(res)
  //   }).catch(err => {
  //     console.error(err)
  //   })
  // },

  
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    if (typeof this.getTabBar === 'function' && this.getTabBar()) { this.getTabBar().setData({ active: 0 }) }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    if (this.data.index) {
      this.getRecoData(res => {
        wx.stopPullDownRefresh();
      });
      this.pageData.skip = 0; 
    }
    else {
      this.getIdenData(res => {
        wx.stopPullDownRefresh();
      });
      this.pageData.skip = 0; 
    }
  },
  getRecoData: function (callback) {
    if (!callback) {
      callback = res => { }
    }
    wx.showLoading({
      title: '数据加载中',
    })
    paper.skip(this.pageData.skip).get().then(res => {
      let oldData = this.data.recommend;
      this.setData({
        recommend: oldData.concat(res.data),
      }, res => {
        this.pageData.skip = this.pageData.skip + 3;
        wx.hideLoading()
        callback();
      })
    })
  },
  getIdenData: function (callback) {
    if (!callback) {
      callback = res => { }
    }
    wx.showLoading({
      title: '数据加载中',
    })
    identity.skip(this.pageData.skip).get().then(res => {
      let oldData = this.data.identity
      this.setData({
        identity: oldData.concat(res.data),
      }, res => {
        this.pageData.skip = this.pageData.skip + 3;
        wx.hideLoading()
        callback();
      })
    })
  },
  pageData: {
    skip: 0
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (this.data.index) {
      this.getRecoData(res => {
        wx.stopPullDownRefresh();
      });
      this.pageData.skip = 0;
    }
    else {
      this.getIdenData(res => {
        wx.stopPullDownRefresh();
      });
      this.pageData.skip = 0;
    }
  },
  getRecoData: function (callback) {
    if (!callback) {
      callback = res => { }
    }
    wx.showLoading({
      title: '数据加载中',
    })
    paper.skip(this.pageData.skip).get().then(res => {
      let oldData = this.data.recommend;
      this.setData({
        recommend: oldData.concat(res.data),
      }, res => {
        this.pageData.skip = this.pageData.skip + 3;
        wx.hideLoading()
        callback();
      })
    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})