// pages/discern/discern.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    num: 0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
    this.data.num++;  /*设置中间页面进行跳转*/
    if (this.data.num % 2 == 0) {
      wx.switchTab({
        url: '/pages/focus/focus'
      });
    } else {
      wx.navigateTo({
        url: '/pages/discern/item/item'
      })
    }
    if (typeof this.getTabBar === 'function' && this.getTabBar()) { this.getTabBar().setData({ active: 2 }) }
  },

  

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})