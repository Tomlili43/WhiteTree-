// pages/discover/discover.js
const db = wx.cloud.database();
const userInfo = db.collection('userInfo')
Page({
 
  /**
   * 页面的初始数据
   */
  data: {
    value: '',
    array: [{
      _id: 0,
      name: "",
      sex: "",

    }],
    

    topPPT: [
      { name: "【识别】：柑橘黄龙病",
        imagePath: "/images/juzi.jpg",
        path: "/pages/discover/topPPT/ppt1/ppt1",},

      { name: "【综合防治】：草莓白粉病",
        imagePath: "/images/fanqie.jpg",
        path: "/pages/discover/topPPT/ppt2/ppt2",},

      { name: "【识别】：草莓白粉病",
        imagePath: "/images/juzi.jpg",
        path: "/pages/discover/topPPT/ppt3/ppt3",},

      { name: "【综合防治】：番茄溃疡病",
        imagePath: "/images/fanqie.jpg",
        path: "/pages/discover/topPPT/ppt4/ppt4",
      },
    ],

    bingchonghaiyujing: [
      { name: "山竹灾后复产系列-蔬菜篇", 
        path: "/pages/discover/bingchonghaiyujing/page1/page1",
        image:"/images/juzi.jpg"},

      { name: "山竹灾后复产系列-粮食篇",
        path: "/pages/discover/bingchonghaiyujing/page1/page1",
        image:"/images/fanqie.jpg"},

      { name: "广东冬钟蔬菜病虫发生动态",
        path: "/pages/discover/bingchonghaiyujing/page1/page1",
        image: "/images/juzi.jpg"},

      { name: "山竹灾后复产系列-甘薯篇",
        path: "/pages/discover/bingchonghaiyujing/page1/page1", 
        image: "/images/fanqie.jpg"},
    ],

    bingchonghaifangzhi:[
      { path: "/pages/discover/bingchonghaifangzhi/page1/page1" },
      { path: "/pages/discover/bingchonghaifangzhi/page2/page2" },
      { path: "/pages/discover/bingchonghaifangzhi/page3/page3" },
      { path: "/pages/discover/bingchonghaifangzhi/page4/page4" },
    ]
  },
  onChange(e) {
    this.setData({
      value: e.detail
    });
  },
  // this.data.value代表输入框的数据
  onSearch() {
    var plant = this.data.value
    console.log('搜索' + plant);
    this.dbSelect(plant)

  },
  dbSelect: function (n) {
    const db = wx.cloud.database()
    var me = this

    console.log("s3" + n)

    db.collection('todos').where({
      name: n
    }).get({
      success: function (res) {
        console.log(res)
        // me.setData({
        //   name: res.data[0].name,
        //   sex: res.data[0].sex,
        //   _id: res.data[0]._id
        // })
      }, fail: console.error
    })

  },

  onClick() {
    var plant = this.data.value
    console.log('搜索' + plant);
    this.dbSelect(plant)
  },
  getUserInfo: function (result) {
    console.log(result.detail.userInfo);
    userInfo.add({
      data: result.detail.userInfo
    }).then(res => {
      console.log(res)
    }).catch(err => {
      console.error(err)
    })
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      search: this.search.bind(this)
    })
  },

  search: function (value) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        resolve([{ text: '搜索结果', value: 1 }, { text: '搜索结果2', value: 2 }])
      }, 200)
    })
  },

  selectResult: function (e) {
    console.log('select result', e.detail)
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    if (typeof this.getTabBar === 'function' && this.getTabBar()) { this.getTabBar().setData({ active: 1 }) }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})