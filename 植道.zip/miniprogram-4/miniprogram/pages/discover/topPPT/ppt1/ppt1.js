// pages/discover/topPPT/ppt1/ppt1.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

    item: {
      topPPT: [
        { imagePath: "/images/juzi.jpg", },
        { imagePath: "/images/green.png", },
        { imagePath: "/images/juzi.jpg", },
        { imagePath: "/images/green.png", },
        { imagePath: "/images/juzi.jpg", },
        { imagePath: "/images/green.png", },
        { imagePath: "/images/juzi.jpg", },
        { imagePath: "/images/green.png", },
      ],

      recommend:
      {
        path: "/pages/focus/recommend/recommend1",
        avatar: "/images/fanqie.jpg",
        writer: "邓玲",
        title: "这才是真正的柑橘痂疮病",
        content1: "巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉",
        content2: "拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉",
        date: "2019-02-20",
        like: 0,
        likeicon: "good-job-o",
        comment: 0,
        view: 0,
      },
      counter: 0,
    }
  },

  /**
   * topPPT: [
      { imagePath: "/images/juzi.jpg", },
      { imagePath: "/images/green.png", },
      { imagePath: "/images/juzi.jpg", },
      { imagePath: "/images/green.png", },
      { imagePath: "/images/juzi.jpg", },
      { imagePath: "/images/green.png", },
      { imagePath: "/images/juzi.jpg", },
      { imagePath: "/images/green.png", },
    ],

    recommend:
    {   path:"/pages/focus/recommend/recommend1",
        avatar: "/images/fanqie.jpg",
        writer: "邓玲",
        title: "这才是真正的柑橘痂疮病",
        content1: "巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉",
        content2:"拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉巴拉",
        date: "2019-02-20",
        like: 0,
        likeicon: "good-job-o",
        comment: 0,
        view: 0,
      },
    counter:0,
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  // 点赞
  dianzan: function (event) {
    this.setData({
      counter: this.data.counter + 1
    })

    if (this.data.counter % 2 == 1) {
      this.setData({
        "recommend.like": this.data.recommend.like + 1,
        "recommend.likeicon": "good-job"
      })
      wx.showToast({
        title: "点赞成功"
      })
    } else {
      this.setData({
        "recommend.like": this.data.recommend.like - 1,
        "recommend.likeicon": "good-job-o"
      })
      wx.showToast({
        title: "取消点赞"
      })
    }
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})