// pages/me/me.js
const app = getApp()
const db = wx.cloud.database();
const userInfo = db.collection('userInfo')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo: null,
     cell:[
       { name: "我的发帖", 
         path: "/pages/me/wodefatie/wodefatie",
         iconpath: "/images/icons/wodefatie.png"},

       { name: "我的识别",
         path: "/pages/me/wodeshibie/wodeshibie",
         iconpath: "/images/icons/wodeshibie.png"
         },

       { name: "我的收藏",
         path: "/pages/me/wodeshoucang/wodeshoucang",
         iconpath: "/images/icons/wodeshoucang.png" 
         },
       {
         name: "意见反馈",
         path: "/pages/me/yijianfankui/yijianfankui",
         iconpath: "/images/icons/yijianfankui.png"
         },

       { name: "通知",
         path: "/pages/me/tongzhi/tongzhi",
         iconpath: "/images/icons/tongzhi.png" 
         }
     ]
  },
  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   
    if (typeof this.getTabBar === 'function' && this.getTabBar()) { this.getTabBar().setData({ active: 3 }) }
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  getUserInfo: function (e) {
    console.log('getUserInfo', e)
    wx.cloud.callFunction({
      // 云函数名称
      name: 'login',
      // 传给云函数的参数
      data: {
        a: 1,
        b: 2,
      },
      success: res => {

        console.log(res.result.openid)
        e.detail.userInfo.openid = res.result.openid
        app.globalData.userInfo = e.detail.userInfo
        this.setData({
          userInfo: e.detail.userInfo,
          hasUserInfo: true
        }, res => {
          console.log('正式', this.data.userInfo)
          console.log('正式', app.globalData.userInfo)


        })
        wx.setStorageSync('userInfo', e.detail.userInfo)
      },
      fail: console.error
    })

    db.collection('ZDUser').add({
      // data 字段表示需新增的 JSON 数据
      data: {
        nickName: e.detail.userInfo.nickName,
        avatarUrl: e.detail.userInfo.avatarUrl,
        gender: e.detail.userInfo.gender,
        province: e.detail.userInfo.province,
        city: e.detail.userInfo.city,
        country: e.detail.userInfo.country,
      },
      success: function (res2) {
        // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
        console.log(res2)
      }, fail: console.error
    })

  },
})