// miniprogram/custom-tab-bar/index.js
Component({
  data: {
    active: 0,
    list:[
    {"pagePath": "/pages/focus/focus"},
    {"pagePath": "/pages/discover/discover"},
    {"pagePath": "/pages/discern/discern"},
    {"pagePath": "/pages/me/me"}]

  },
  attached() {
  },
  methods: {
    onChange(event) {
      // event.detail 的值为当前选中项的索引
      
      this.setData({ active: event.detail });
      const url = this.data.list[event.detail].pagePath
      wx.switchTab({ url })
    },
  }
  
});





