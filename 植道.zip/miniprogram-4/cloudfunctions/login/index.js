// 云函数入口文件
const cloud = require('wx-server-sdk')
cloud.init()


exports.main = (event) => {
  const wxInfo = cloud.getWXContext()
  return {
    sum: event.a + event.b,
    wxInfo,
  }
}